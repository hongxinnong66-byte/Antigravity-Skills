;(() => {
  const {ipcMain,nativeImage,BrowserWindow}=require('electron');
  const fs=require('fs'), path=require('path');
  const library=__STEAM_APPS__;
  const profile=s=>[s[process.env.USERNAME],...Object.values(s)].find(u=>u?.general?.wallpaperconfig?.selectedwallpapers?.Monitor0?.file);
  const config=path.join(library,'common/wallpaper_engine/config.json');
  const roots=['workshop/content/431960','common/wallpaper_engine/projects'].map(p=>path.resolve(library,p).toLowerCase()+path.sep);
  const prefs=path.join(require('electron').app.getPath('userData'),'workspace-wallpaper-choice.json');
  const catalog=path.resolve(library,'workshop/content/431960');
  const trusted=e=>e.senderFrame===e.sender.mainFrame && BrowserWindow.fromWebContents(e.sender) && new URL(e.senderFrame.url).hostname==='127.0.0.1';
  let selected='';
  let pool=[], enabled=false, next=0;
  function saveChoice(id, shuffle){
    fs.writeFileSync(prefs+'.tmp',JSON.stringify({selected:id,shuffle,pool:shuffle?pool:[]}));
    fs.renameSync(prefs+'.tmp',prefs);
    selected=id;enabled=shuffle;
  }
  try{
    const saved=JSON.parse(fs.readFileSync(prefs,'utf8'));
    const id=typeof saved==='string'?saved:saved.selected;
    selected=/^\d+$/.test(id)?id:'';
    pool=Array.isArray(saved.pool)?saved.pool.filter(n=>typeof n==='string' && /^\d+$/.test(n)):[];
    enabled=saved.shuffle===true && pool.length>0;
    next=Date.now()+60000;
  }catch{}
  function randomChoice(){
    const candidates=pool.filter(n=>n!==selected && fs.existsSync(path.join(catalog,n,'project.json')));
    return candidates.length?candidates[require('crypto').randomInt(candidates.length)]:selected;
  }
  ipcMain.handle('workspace-follow-toggle',(e,on)=>{
    if(!trusted(e) || typeof on!=='boolean')throw Error('Invalid mode');
    if(on){saveChoice('',false);}
    else{
      const configData=JSON.parse(fs.readFileSync(config,'utf8').replace(/^\uFEFF/,''));
      const file=profile(configData).general.wallpaperconfig.selectedwallpapers.Monitor0.file;
      const current=path.dirname(path.resolve(file));
      const match=pool.find(id=>path.join(catalog,id).toLowerCase()===current.toLowerCase());
      const choice=match||pool[0];
      if(!choice)throw Error('图库没有可选壁纸');
      saveChoice(choice,false);
    }
    return selected;
  });
  ipcMain.handle('workspace-shuffle',(e,on)=>{
    if(!trusted(e) || typeof on!=='boolean' || (on && !pool.length))throw Error('图库未就绪');
    saveChoice(on?randomChoice():selected,on);
    next=Date.now()+60000;
    return {selected,enabled};
  });
  ipcMain.handle('workspace-gallery-list',async e=>{
    if(!trusted(e))return null;
    const items=[];
    for(const entry of await fs.promises.readdir(catalog,{withFileTypes:true})){
      if(!entry.isDirectory() || !/^\d+$/.test(entry.name))continue;
      try{
        const dir=path.join(catalog,entry.name);
        const meta=JSON.parse((await fs.promises.readFile(path.join(dir,'project.json'),'utf8')).replace(/^\uFEFF/,''));
        const preview=await fs.promises.realpath(path.join(dir,path.basename(meta.preview || 'preview.jpg')));
        if(path.dirname(preview).toLowerCase()!==dir.toLowerCase() || !/\.(png|jpe?g|gif|webp|bmp)$/i.test(preview) || (await fs.promises.stat(preview)).size>32*1024*1024)continue;
        const image=nativeImage.createFromPath(preview);
        if(image.isEmpty())continue;
        items.push({id:entry.name,title:(meta.type==="video"?"【视频】":/\.gif$/i.test(preview)?"【动图】":"")+String(meta.title||entry.name),thumb:image.resize({width:144}).toJPEG(65).toString('base64')});
      }catch{}
    }
    pool=items.map(item=>item.id); return {selected,items,enabled};
  });
  ipcMain.handle('workspace-gallery-select',(e,id)=>{
    if(!trusted(e) || typeof id!=='string' || (id!=='' && !/^\d+$/.test(id)))throw Error('Invalid selection');
    saveChoice(id,false);
  });
  const mediaFiles=new Map();
  function mediaUrl(event,file,mime){
    mediaFiles.set(event.sender.id,file);
    return mime;
  }
  ipcMain.handle('workspace-media-chunk',async(e,offset)=>{
    if(!trusted(e) || !Number.isSafeInteger(offset) || offset<0)throw Error('Invalid request');
    const fd=await fs.promises.open(mediaFiles.get(e.sender.id),'r');
    try{
      const size=(await fd.stat()).size;
      const buf=Buffer.alloc(Math.max(0,Math.min(4*1024*1024,size-offset)));
      const {bytesRead}=await fd.read(buf,0,buf.length,offset);
      return {data:buf.subarray(0,bytesRead),done:offset+bytesRead>=size};
    }finally{await fd.close();}
  });
  const opacityFile=path.join(path.dirname(prefs),'workspace-wallpaper-opacity.json');
  let levels=Object.create(null);
  try{Object.assign(levels,JSON.parse(fs.readFileSync(opacityFile,'utf8')));}catch{}
  const activeKeys=new Map();
  ipcMain.handle('workspace-wallpaper-opacity', (e,key,value)=>{
    if(!trusted(e) || activeKeys.get(e.sender.id)!==key || !Number.isInteger(value) || value<0 || value>100)return false;
    levels[key]=value;
    fs.writeFileSync(opacityFile+'.tmp',JSON.stringify(levels));
    fs.renameSync(opacityFile+'.tmp',opacityFile);
    return true;
  });
  let cachedKey='', cachedImage='';
  ipcMain.handle('workspace-wallpaper-engine-preview',async(event,previous)=>{
    try {
      const frame=event.senderFrame;
      if(frame!==event.sender.mainFrame || !BrowserWindow.fromWebContents(event.sender) || new URL(frame.url).hostname!=='127.0.0.1') return null;
      if(enabled && Date.now()>=next){
        next=Date.now()+60000;
        saveChoice(randomChoice(),true);
      }
      let dir;
      if(selected){dir=await fs.promises.realpath(path.join(catalog,selected));}
      else{
        const settings=JSON.parse((await fs.promises.readFile(config,'utf8')).replace(/^\uFEFF/,''));
        dir=await fs.promises.realpath(path.dirname(profile(settings).general.wallpaperconfig.selectedwallpapers.Monitor0.file));
      }
      if(!roots.some(root=>(dir.toLowerCase()+path.sep).startsWith(root))) return null;
      const key=dir.toLowerCase(); activeKeys.set(event.sender.id,key); const opacity=levels[key]??38;
      const project=JSON.parse((await fs.promises.readFile(path.join(dir,'project.json'),'utf8')).replace(/^\uFEFF/,''));
      const preview=await fs.promises.realpath(path.join(dir,path.basename(project.preview || 'preview.jpg')));
      if(path.dirname(preview).toLowerCase()!==dir.toLowerCase() || !/\.(png|jpe?g|gif|webp|bmp)$/i.test(preview))return null;
      const ext=path.extname(project.file||'').toLowerCase();
      const mime={'.mp4':'video/mp4','.webm':'video/webm','.m4v':'video/mp4'}[ext];
      if((project.type==='video' && mime) || /\.gif$/i.test(preview)){
        const movie=project.type==='video' && mime;
        const file=movie?await fs.promises.realpath(path.join(dir,path.basename(project.file))):preview;
        if(path.dirname(file).toLowerCase()!==dir.toLowerCase())return null;
        const id=file+'|'+(await fs.promises.stat(file)).mtimeMs;
        if(previous===id)return null;
        return {id,key,opacity,kind:movie?'video':'gif',url:mediaUrl(event,file,movie?mime:'image/gif')};
      }
      const stat=await fs.promises.stat(preview);
      const id=preview+'|'+stat.mtimeMs;
      if(previous===id || stat.size>32*1024*1024)return null;
      if(cachedKey!==id){
        const img=nativeImage.createFromPath(preview);
        if(img.isEmpty())return null;
        cachedImage=img.toJPEG(88).toString('base64');
        cachedKey=id;
      }
      return {id,key,opacity,image:cachedImage};
    }catch{return null;}
  });
})();







