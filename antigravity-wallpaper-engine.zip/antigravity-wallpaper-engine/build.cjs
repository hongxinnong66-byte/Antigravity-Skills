const fs = require('fs'), crypto = require('crypto'), path = require('path');
const [src,steamApps,out]=process.argv.slice(2);
if(!src || !steamApps || !out || !fs.existsSync(path.join(steamApps,'common/wallpaper_engine/config.json')))throw Error('Usage: node build.cjs <original app.asar> <Steam steamapps directory> <new output>');
const b=fs.readFileSync(src), digest=d=>crypto.createHash('sha256').update(d).digest('hex');
if(!['e057115571cf5085406d20f2427a5afac272b712ec84332c7157da0113d4b2d0','b195c3306d03fac8f4ead4fea424e53a06bb88f3dc154df9194b4616cc476e5b'].includes(digest(b)))throw Error('Unknown Antigravity baseline');
const h=JSON.parse(b.subarray(16,16+b.readUInt32LE(12))), body=b.subarray(8+b.readUInt32LE(4));
const parts=[body];
let offset=body.length;
for(const name of ['main','preload']){
 const f=h.files.dist.files[name+'.js'];
 const code=Buffer.concat([body.subarray(+f.offset,+f.offset+f.size),Buffer.from('\n'),Buffer.from(fs.readFileSync(path.join(__dirname,name+'.js'),'utf8').replace('__STEAM_APPS__',()=>JSON.stringify(path.resolve(steamApps))))]);
 new Function(code.toString());
 f.offset=String(offset);f.size=code.length;offset+=code.length;parts.push(code);
 if(f.integrity){f.integrity.hash=digest(code);f.integrity.blocks=[];for(let i=0;i<code.length;i+=f.integrity.blockSize)f.integrity.blocks.push(digest(code.subarray(i,i+f.integrity.blockSize)));}
}
const json=Buffer.from(JSON.stringify(h)), pad=Math.ceil((4+json.length)/4)*4, hdr=Buffer.alloc(12+pad);
hdr.writeUInt32LE(4);hdr.writeUInt32LE(pad+4,4);hdr.writeUInt32LE(pad,8);hdr.writeUInt32LE(json.length,12);json.copy(hdr,16);
fs.writeFileSync(out,Buffer.concat([hdr,...parts]),{flag:'wx'});






