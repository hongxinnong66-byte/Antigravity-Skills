---
name: antigravity-wallpaper-engine
description: 在 Windows 的 Antigravity 桌面工作区安装、迁移或恢复 Wallpaper Engine 壁纸联动，支持独立图库、动态壁纸、随机播放和逐壁纸透明度。
---

# 安装与迁移

在新电脑将本仓库克隆到 ~/.codex/skills/antigravity-wallpaper-engine。打开新聊天后可说「使用 $antigravity-wallpaper-engine 设置我的工作区」。

1. 定位 Antigravity 桌面应用的 Antigravity.exe 和同目录 resources/app.asar。构建器支持 2.35.2 的官方英文包及社区 v2.35.2 汉化包，按 SHA-256 识别。其他版本先核对主进程、preload 和工作区来源再移植。
2. 从 HKCU\Software\Valve\Steam 的 SteamPath 读取 steamapps/libraryfolders.vdf，找到含 common/wallpaper_engine/config.json 和 workshop/content/431960 的 steamapps 目录。先在 Wallpaper Engine 应用一张已订阅壁纸。多用户机器检查配置中的 Monitor0 属于当前用户。
3. 在本 Skill 目录运行 node build.cjs <原版或汉化版app.asar路径> <steamapps目录> <同目录新文件路径>。给含空格的路径加引号。输入使用当前客户端的对应原件，输出使用尚不存在的临时文件。构建失败时保留现有安装。
4. 正常退出目标桌面应用，确认其进程退出。检查备份路径尚未占用，在 PowerShell 中使用 [IO.File]::Replace($stage,$archive,$backup) 原子替换并保存原件。三个变量分别是新文件、现用 app.asar、同目录版本化备份的绝对路径。从原有入口重新启动。
5. 打开右下角「选择壁纸」，确认订阅图库、两个滑动开关、可见度滑杆和右上角关闭按钮。选视频确认连续播放，调整可见度，换图再返回验证记忆。默认可见度 38%。跟随桌面读取 Monitor0；随机播放在工作区可见时每分钟切换，两个开关互斥。手动选图关闭两种自动模式。视频静音循环；场景和网页使用项目预览，GIF 预览可动。Ctrl+Alt+B 可选本地图片。
6. 偏好保存在 Electron userData 的 workspace-wallpaper-*.json。新电脑可重新选择；可见度记录使用本机路径。视频在内存中加载，大文件占用较多内存。
7. 恢复时确认客户端仍是备份对应版本，正常退出，复制备份到同目录临时文件，再使用 File.Replace 替换当前包。升级后重新核对适配版本。

main.js 读取图库并保存模式。preload.js 绘制背景与控制面板。build.cjs 在使用者电脑填入 Steam 路径，并更新 ASAR 索引和完整性记录。仓库只保存源文件，订阅资源由 Steam 管理。
