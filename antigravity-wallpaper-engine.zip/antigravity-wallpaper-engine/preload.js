window.addEventListener('DOMContentLoaded', () => {
  if (window.top !== window || !/^(localhost|127\.0\.0\.1)$/.test(location.hostname) && !['app:', 'antigravity:'].includes(location.protocol)) return;
  const key = 'workspace-wallpaper-v1';
  const canvas = document.createElement('canvas');
  canvas.setAttribute('role','img');
  canvas.setAttribute('aria-label','工作区背景图');
  canvas.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;object-fit:cover;pointer-events:none;opacity:.18;z-index:1000';
  const ctx = canvas.getContext('2d');
  async function draw(blob) {
    const bitmap = await createImageBitmap(blob);
    const scale = Math.min(1,1600/Math.max(bitmap.width,bitmap.height));
    canvas.width = Math.max(1,Math.round(bitmap.width*scale));
    canvas.height = Math.max(1,Math.round(bitmap.height*scale));
    ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);
    bitmap.close();
    document.body.appendChild(canvas);
  }
  function decode(data) {
    return new Blob([Uint8Array.from(atob(data), c => c.charCodeAt(0))],{type:'image/jpeg'});
  }
  document.body.append(canvas); if(localStorage.getItem(key))draw(decode(localStorage.getItem(key)));
  window.addEventListener('keydown', e => {
    if (!(e.ctrlKey && e.altKey && e.code === 'KeyB')) return;
    e.preventDefault();
    const picker = document.createElement('input');
    picker.type = 'file';
    picker.accept = 'image/jpeg,image/png,image/webp';
    picker.onchange = async () => {
      if (!picker.files.length) return;
      await draw(picker.files[0]);
      localStorage.setItem(key,canvas.toDataURL('image/jpeg',.78).split(',')[1]);
    };
    picker.click();
  });
});

let wallpaperKey='', wallpaperLevel=38;
;window.addEventListener('DOMContentLoaded',()=>{
  if(window.top!==window || location.hostname!=='127.0.0.1')return;
  let id='', media=null;
  async function refresh(){
    try{
      const canvas=document.querySelector('canvas[aria-label="工作区背景图"],canvas[aria-label="Wallpaper Engine 工作区背景图"]');
      if(canvas && !document.hidden){
        const result=await require('electron').ipcRenderer.invoke('workspace-wallpaper-engine-preview',id);
        if(result){
          wallpaperKey=result.key;wallpaperLevel=result.opacity;
          document.documentElement.style.setProperty('--workspace-wallpaper-opacity',String(wallpaperLevel/100));
          canvas.style.opacity='var(--workspace-wallpaper-opacity)';
          window.dispatchEvent(new Event('workspace-wallpaper-level'));
          if(media){URL.revokeObjectURL(media.src);media.remove();if(media.tagName==='VIDEO'){media.removeAttribute('src');media.load();}media=null;}
          canvas.style.visibility='';
          if(result.url){
            media=document.createElement(result.kind==='video'?'video':'img');
            media.style.cssText=canvas.style.cssText;
            media.setAttribute('role','img');
            media.setAttribute('aria-label','正在加载动态壁纸');
            if(result.kind==='video'){
              media.muted=true;media.loop=true;media.autoplay=true;media.playsInline=true;
              media.ontimeupdate=()=>{if(media && media.currentTime>1){media.setAttribute('aria-label','工作区动态壁纸播放中');canvas.style.visibility='hidden';}};
            }else{media.onload=()=>{media.setAttribute('aria-label','工作区动图');canvas.style.visibility='hidden';};}
            const chunks=[];let offset=0;
            while(true){
              const chunk=await require('electron').ipcRenderer.invoke('workspace-media-chunk',offset);
              chunks.push(chunk.data);offset+=chunk.data.length;
              if(chunk.done)break;
            }
            media.src=URL.createObjectURL(new Blob(chunks,{type:result.url}));document.body.append(media);id=result.id;return;
          }
          const bytes=Uint8Array.from(atob(result.image),c=>c.charCodeAt(0));
          const img=await createImageBitmap(new Blob([bytes],{type:'image/jpeg'}));
          canvas.width=img.width;
          canvas.height=img.height;
          canvas.getContext('2d').drawImage(img,0,0);
          img.close();
          canvas.setAttribute('aria-label','Wallpaper Engine 工作区背景图');
          id=result.id;
        }
      }
    }catch{}finally{setTimeout(refresh,3000);}
  }
  refresh();
});
;window.addEventListener('DOMContentLoaded',()=>{
  if(window.top!==window || location.hostname!=='127.0.0.1')return;
  const ipc=require('electron').ipcRenderer;
  const el=(tag,text)=>{const n=document.createElement(tag);if(text)n.textContent=text;return n;};
  const launch=el('button','选择壁纸');
  launch.style.cssText='position:fixed;right:16px;bottom:10px;z-index:1001;border:1px solid #686876;border-radius:18px;padding:4px 12px;background:#272733;color:white;cursor:pointer;font:12px system-ui';
  document.body.append(launch);
  launch.onclick=async()=>{
    const dialog=el('dialog');
    dialog.setAttribute('aria-label','工作区壁纸');
    dialog.style.cssText='margin:auto;width:min(760px,90vw);max-height:78vh;overflow:auto;background:#252532;color:white;border:1px solid #676778;border-radius:12px;padding:18px';
    const top=el('div');top.style.cssText='display:flex;gap:12px;align-items:center;position:sticky;top:0;background:#252532;padding:6px;z-index:1';
    const heading=el('strong','工作区壁纸'),close=el('button','关闭');
    const css=el('style');
    css.textContent='.wp-switch{display:inline-flex;align-items:center;gap:7px;background:transparent;color:inherit;border:0;cursor:pointer}.wp-switch i{width:32px;height:18px;border-radius:12px;background:#666976;display:inline-flex;align-items:center;padding:2px;box-sizing:border-box}.wp-switch i::after{content:"";width:14px;height:14px;border-radius:50%;background:white}.wp-switch[aria-checked="true"] i{background:#3779bd}.wp-switch[aria-checked="true"] i::after{margin-left:auto}';
    dialog.append(css);
    function toggle(label){
      const btn=el('button',label);btn.className='wp-switch';btn.setAttribute('role','switch');
      btn.setAttribute('aria-checked','false');btn.append(el('i'));btn.disabled=true;return btn;
    }
    const follow=toggle('跟随桌面'),shuffle=toggle('随机播放');
    function setMode(selected,enabled){
      follow.setAttribute('aria-checked',String(!selected && !enabled));
      shuffle.setAttribute('aria-checked',String(enabled));
      for(const label of grid.querySelectorAll('[data-wallpaper]')){
        label.textContent=(label.dataset.wallpaper===selected?'✓ ':'')+label.dataset.title;
      }
    }
    let hasItems=false;
    async function change(btn){
      follow.disabled=shuffle.disabled=true;
      try{
        const on=btn.getAttribute('aria-checked')!=='true';
        if(btn===follow)setMode(await ipc.invoke('workspace-follow-toggle',on),false);
        else{const mode=await ipc.invoke('workspace-shuffle',on);setMode(mode.selected,mode.enabled);}
      }finally{follow.disabled=shuffle.disabled=!hasItems;}
    }
    follow.onclick=()=>change(follow);shuffle.onclick=()=>change(shuffle);
    close.style.marginInlineStart='auto';
    top.append(heading,follow,shuffle,close);dialog.append(top);
    const bar=el('label','壁纸可见度 ');
    bar.style.cssText='display:flex;align-items:center;gap:12px;margin:8px 6px;color:white';
    const slider=el('input');slider.type='range';slider.min='0';slider.max='100';slider.step='1';
    slider.setAttribute('aria-label','壁纸可见度');slider.style.width='min(250px,38vw)';
    const number=el('output');
    function display(){slider.value=wallpaperLevel;number.textContent=wallpaperLevel+'%';slider.disabled=!wallpaperKey;}
    display();
    window.addEventListener('workspace-wallpaper-level',display);
    dialog.addEventListener('close',()=>window.removeEventListener('workspace-wallpaper-level',display),{once:true});
    slider.oninput=()=>{
      wallpaperLevel=Number(slider.value);number.textContent=wallpaperLevel+'%';
      document.documentElement.style.setProperty('--workspace-wallpaper-opacity',String(wallpaperLevel/100));
    };
    slider.onchange=async()=>{try{if(!await ipc.invoke('workspace-wallpaper-opacity',wallpaperKey,wallpaperLevel))display();}catch{number.textContent+='（未保存）';}};
    bar.append(slider,number);dialog.append(bar);
    const grid=el('div','正在读取已订阅壁纸…');
    grid.style.cssText='display:grid;grid-template-columns:repeat(auto-fill,minmax(136px,1fr));gap:10px;margin-top:12px';
    dialog.append(grid);document.body.append(dialog);dialog.showModal();
    dialog.onclose=()=>dialog.remove();close.onclick=()=>dialog.close();
    async function choose(id){await ipc.invoke('workspace-gallery-select',id);dialog.close();}

    try{
      const {items,selected,enabled}=await ipc.invoke('workspace-gallery-list');
      if(!dialog.open)return;
      hasItems=items.length>0; follow.disabled=shuffle.disabled=!hasItems; setMode(selected,enabled);

      grid.textContent=items.length?'':'未找到带预览图的已订阅壁纸';
      for(const item of items){
        const btn=el('button');btn.style.cssText='display:flex;flex-direction:column;align-items:stretch;gap:4px;text-align:left;cursor:pointer;padding:5px;border:1px solid #666;border-radius:6px';
        const img=el('img');img.src='data:image/jpeg;base64,'+item.thumb;img.alt='';img.style.cssText='width:100%;height:80px;object-fit:cover;border-radius:4px';
        const text=el('span',(item.id===selected?'✓ ':'')+item.title);text.dataset.wallpaper=item.id;text.dataset.title=item.title;btn.append(img,text);btn.onclick=()=>choose(item.id);grid.append(btn);
      }
    }catch{grid.textContent='读取图库失败，请关闭后重试。';}
  };
});








